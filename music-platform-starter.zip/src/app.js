import "dotenv/config";
import express from "express";
import morgan from "morgan";
import cors from "cors";
import { connectDB } from "./db.js";
import songsRouter from "./routes/songs.routes.js";
import playlistsRouter from "./routes/playlists.routes.js";
import errorHandler from "./middleware/errorHandler.js";

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// Servir archivos subidos (streaming simple de MP3)
app.use("/uploads", express.static("uploads"));

// Rutas
app.use("/api/songs", songsRouter);
app.use("/api/playlists", playlistsRouter);

//  Healthcheck
app.get("/api/health", (_, res) => res.json({ ok: true }));

// Manejo de errores
app.use(errorHandler);

const PORT = process.env.PORT || 4000;
connectDB(process.env.MONGODB_URI)
  .then(() => app.listen(PORT, () => console.log(`🚀 Server on http://localhost:${PORT}`)))
  .catch((err) => {
    console.error("❌ Error al conectar DB:", err);
    process.exit(1);
  });
