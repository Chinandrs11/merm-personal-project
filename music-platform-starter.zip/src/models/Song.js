import mongoose from "mongoose";

const songSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, index: "text" },
    artist: { type: String, required: true, trim: true, index: true },
    filePath: { type: String, required: true },
    durationSec: { type: Number, default: null },
    uploader: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  },
  { timestamps: true }
);

songSchema.index({ artist: 1, title: 1 });

export default mongoose.model("Song", songSchema);
