import { Router } from "express";
import Playlist from "../models/Playlist.js";
import Song from "../models/Song.js";

const router = Router();

// CREATE
router.post("/", async (req, res, next) => {
  try {
    const { name, ownerId, isPublic = true, songs = [] } = req.body;
    const playlist = await Playlist.create({
      name,
      owner: ownerId || null,
      songs,
      isPublic
    });
    res.status(201).json(playlist);
  } catch (err) { next(err); }
});

// READ: listar playlists
router.get("/", async (req, res, next) => {
  try {
    const { ownerId } = req.query;
    const filter = ownerId ? { owner: ownerId } : {};
    const items = await Playlist.find(filter).sort({ createdAt: -1 });
    res.json(items);
  } catch (err) { next(err); }
});

// READ: detalle con populate
router.get("/:id", async (req, res, next) => {
  try {
    const playlist = await Playlist.findById(req.params.id).populate("songs");
    if (!playlist) return res.status(404).json({ message: "Playlist no encontrada" });
    res.json(playlist);
  } catch (err) { next(err); }
});

// UPDATE nombre / visibilidad
router.put("/:id", async (req, res, next) => {
  try {
    const { name, isPublic } = req.body;
    const update = {};
    if (name !== undefined) update.name = name;
    if (isPublic !== undefined) update.isPublic = isPublic;

    const playlist = await Playlist.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!playlist) return res.status(404).json({ message: "Playlist no encontrada" });
    res.json(playlist);
  } catch (err) { next(err); }
});

// PATCH: agregar canción
router.patch("/:id/add", async (req, res, next) => {
  try {
    const { songId } = req.body;
    const song = await Song.findById(songId);
    if (!song) return res.status(404).json({ message: "Canción no encontrada" });

    const playlist = await Playlist.findByIdAndUpdate(
      req.params.id,
      { $addToSet: { songs: song._id } },
      { new: true }
    ).populate("songs");

    if (!playlist) return res.status(404).json({ message: "Playlist no encontrada" });
    res.json(playlist);
  } catch (err) { next(err); }
});

// PATCH: quitar canción
router.patch("/:id/remove", async (req, res, next) => {
  try {
    const { songId } = req.body;
    const playlist = await Playlist.findByIdAndUpdate(
      req.params.id,
      { $pull: { songs: songId } },
      { new: true }
    ).populate("songs");

    if (!playlist) return res.status(404).json({ message: "Playlist no encontrada" });
    res.json(playlist);
  } catch (err) { next(err); }
});

// DELETE
router.delete("/:id", async (req, res, next) => {
  try {
    const playlist = await Playlist.findByIdAndDelete(req.params.id);
    if (!playlist) return res.status(404).json({ message: "Playlist no encontrada" });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

export default router;
