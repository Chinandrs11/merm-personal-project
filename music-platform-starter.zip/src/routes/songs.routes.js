import { Router } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { parseFile } from "music-metadata";
import Song from "../models/Song.js";

const router = Router();

// Configurar multer para MP3
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = "uploads";
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname).toLowerCase());
  }
});

function fileFilter(req, file, cb) {
  const isMp3 = file.mimetype === "audio/mpeg" || file.originalname.toLowerCase().endsWith(".mp3");
  if (!isMp3) return cb(new Error("Solo se permiten archivos MP3"));
  cb(null, true);
}

const upload = multer({ storage, fileFilter, limits: { fileSize: 25 * 1024 * 1024 } });

// CREATE: subir MP3 + metadatos
router.post("/", upload.single("file"), async (req, res, next) => {
  try {
    const { title, artist, uploaderId } = req.body;
    if (!req.file) throw new Error("Archivo MP3 requerido");
    if (!title || !artist) throw new Error("title y artist son requeridos");

    // Lee metadatos (duración) si es posible
    let durationSec = null;
    try {
      const meta = await parseFile(req.file.path);
      durationSec = meta?.format?.duration ? Math.round(meta.format.duration) : null;
    } catch {}

    const song = await Song.create({
      title,
      artist,
      filePath: `/${req.file.path.replace(/\\/g, "/")}`,
      durationSec,
      uploader: uploaderId || null
    });
    res.status(201).json(song);
  } catch (err) { next(err); }
});

// READ: listar canciones (paginado + búsqueda simple)
router.get("/", async (req, res, next) => {
  try {
    const { q, page = 1, limit = 12 } = req.query;
    const filter = q
      ? {
          $or: [
            { title: new RegExp(q, "i") },
            { artist: new RegExp(q, "i") }
          ]
        }
      : {};
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Song.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Song.countDocuments(filter)
    ]);
    res.json({ items, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (err) { next(err); }
});

// READ: obtener una canción
router.get("/:id", async (req, res, next) => {
  try {
    const song = await Song.findById(req.params.id);
    if (!song) return res.status(404).json({ message: "Canción no encontrada" });
    res.json(song);
  } catch (err) { next(err); }
});

// STREAM (HTTP Range)
router.get("/:id/stream", async (req, res, next) => {
  try {
    const song = await Song.findById(req.params.id);
    if (!song) return res.status(404).json({ message: "Canción no encontrada" });
    const fullPath = song.filePath.startsWith("/") ? song.filePath.slice(1) : song.filePath;

    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ message: "Archivo no encontrado" });
    }

    const stat = fs.statSync(fullPath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, "").split("-");
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = end - start + 1;
      const file = fs.createReadStream(fullPath, { start, end });
      res.writeHead(206, {
        "Content-Range": `bytes ${start}-${end}/${fileSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": chunksize,
        "Content-Type": "audio/mpeg"
      });
      file.pipe(res);
    } else {
      res.writeHead(200, {
        "Content-Length": fileSize,
        "Content-Type": "audio/mpeg"
      });
      fs.createReadStream(fullPath).pipe(res);
    }
  } catch (err) { next(err); }
});

// UPDATE
router.put("/:id", upload.single("file"), async (req, res, next) => {
  try {
    const { title, artist } = req.body;
    const update = {};
    if (title) update.title = title;
    if (artist) update.artist = artist;
    if (req.file) update.filePath = `/${req.file.path.replace(/\\/g, "/")}`;

    const song = await Song.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!song) return res.status(404).json({ message: "Canción no encontrada" });
    res.json(song);
  } catch (err) { next(err); }
});

// DELETE
router.delete("/:id", async (req, res, next) => {
  try {
    const song = await Song.findByIdAndDelete(req.params.id);
    if (!song) return res.status(404).json({ message: "Canción no encontrada" });
    const fullPath = song.filePath.startsWith("/") ? song.filePath.slice(1) : song.filePath;
    if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
    res.json({ ok: true });
  } catch (err) { next(err); }
});

export default router;
