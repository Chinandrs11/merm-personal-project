# Music Platform (Node.js + Express + MongoDB)

Subida de MP3 con título y artista, CRUD completo de **canciones** y **playlists**, y streaming con HTTP Range.

## Requisitos
- Node.js 18+
- MongoDB en local (o URI de Atlas)

## Instalación
```bash
npm i
```
Crea `.env` (ya incluido) y ajusta tu `MONGODB_URI` si es necesario.

## Ejecutar en desarrollo
```bash
npm run dev
```
Servidor: `http://localhost:4000`

Healthcheck:
```bash
GET http://localhost:4000/api/health
```

## Seed (datos de prueba)
```bash
node seed.js
```
Crea:
- Usuario demo `andres@example.com`
- 3 canciones con archivos MP3 **vacíos** (placeholder) en `/uploads`
- 1 playlist pública con esas canciones

> Nota: Los MP3 del seed son archivos vacíos (no reproducibles). Sube tus propios `.mp3` con el endpoint de canciones para probar streaming real.

## Endpoints principales

### Canciones
- **POST** `/api/songs` (multipart/form-data)
  - Campos: `title`, `artist`, `file` (MP3), `uploaderId` (opcional)
- **GET** `/api/songs?q=<texto>&page=1&limit=12`
- **GET** `/api/songs/:id`
- **GET** `/api/songs/:id/stream` (stream MP3)
- **PUT** `/api/songs/:id` (puede incluir `file` para reemplazo)
- **DELETE** `/api/songs/:id`

### Playlists
- **POST** `/api/playlists` (JSON)
- **GET** `/api/playlists?ownerId=<id>`
- **GET** `/api/playlists/:id`
- **PUT** `/api/playlists/:id`
- **PATCH** `/api/playlists/:id/add` (JSON: `{ "songId": "<ID>" }`)
- **PATCH** `/api/playlists/:id/remove` (JSON: `{ "songId": "<ID>" }`)
- **DELETE** `/api/playlists/:id`

## Consejos de producción
- Almacenar MP3 en S3/GCS o GridFS (en vez de disco local)
- Límite de tamaño y validaciones de contenido
- Auth (JWT) + permisos por usuario
- Índices de búsqueda
- Rate limiting
- Logs estructurados
