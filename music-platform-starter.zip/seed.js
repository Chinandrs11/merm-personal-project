import "dotenv/config";
import mongoose from "mongoose";
import fs from "fs";
import path from "path";
import User from "./src/models/User.js";
import Song from "./src/models/Song.js";
import Playlist from "./src/models/Playlist.js";
import { connectDB } from "./src/db.js";

async function main() {
  await connectDB(process.env.MONGODB_URI);

  // Limpia colecciones
  await Promise.all([User.deleteMany({}), Song.deleteMany({}), Playlist.deleteMany({})]);

  // Crea usuario demo
  const andres = await User.create({ email: "andres@example.com", name: "Andrés" });

  // Crea archivos MP3 de ejemplo (vacíos, solo para ruta de prueba)
  const uploadsDir = "uploads";
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

  const makeDummy = (fname) => {
    const p = path.join(uploadsDir, fname);
    if (!fs.existsSync(p)) fs.writeFileSync(p, Buffer.from("")); // archivo vacío
    return `/${p}`;
  };

  const s1 = await Song.create({
    title: "Café de la Tarde",
    artist: "Luna Pacífica",
    filePath: makeDummy("cafe-de-la-tarde.mp3"),
    uploader: andres._id
  });

  const s2 = await Song.create({
    title: "Mar Azul",
    artist: "Bahía Norte",
    filePath: makeDummy("mar-azul.mp3"),
    uploader: andres._id
  });

  const s3 = await Song.create({
    title: "Ruta 27",
    artist: "Valle Central",
    filePath: makeDummy("ruta-27.mp3"),
    uploader: andres._id
  });

  const pl = await Playlist.create({
    name: "Rock Tico 2000s",
    owner: andres._id,
    songs: [s1._id, s2._id, s3._id],
    isPublic: true
  });

  console.log("✅ Seed completado:");
  console.log({ user: andres._id.toString(), songs: [s1._id.toString(), s2._id.toString(), s3._id.toString()], playlist: pl._id.toString() });
  await mongoose.disconnect();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
